// terminal.js

var term = new Terminal();
term.open(document.getElementById('terminal'));

var socket = io.connect();

socket.on('output', function (data) {
  term.write(data);
});

term.onData(function (data) {
  socket.emit('input', data);
});

term.onResize(function (size) {
  // 터미널 크기 조정 이벤트를 감지하고 서버로 전송
  socket.emit('resize', size);
});

// 초기 터미널 크기 설정
var initialCols = Math.floor(window.innerWidth / term._core.renderer.dimensions.actualCellWidth);
var initialRows = Math.floor(window.innerHeight / term._core.renderer.dimensions.actualCellHeight);
term.resize(initialCols, initialRows);

socket.on('resize', function (size) {
  term.resize(size.cols, size.rows);
});
