const express = require('express');
const socketIo = require('socket.io');
const pty = require('node-pty');
const os = require('os');
const http = require('http');

// 미리 정의된 함수: 최소값과 최대값 사이의 랜덤 포트 생성
function getRandomPort(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

const app = express();
const server = http.Server(app);
const io = socketIo(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
  const currentUserId = os.userInfo().username;
  // getRandomPort 함수를 사용하여 1000에서 2000 사이의 랜덤 포트 생성
  const containerPort = getRandomPort(1000, 2000);

  // 여기서부터 기존 코드와 동일

  const shell = pty.spawn('docker', ['exec', '-it', currentUserId, 'bash'], {
    name: 'xterm-color',
    cwd: process.env.HOME,
    env: process.env
  });

  shell.on('data', (data) => {
    socket.emit('output', data);
  });

  socket.on('input', (data) => {
    shell.write(data);
  });

  socket.on('resize', (size) => {
    shell.resize(size.col, size.row);
  });

  socket.on('disconnect', () => {
    shell.kill();
  });
});

// 서버를 랜덤 포트로 시작
const PORT = getRandomPort(1000, 2000);
server.listen(PORT, '0.0.0.0', () => {
  console.log(`http://15.165.251.209:${PORT}`);
});

